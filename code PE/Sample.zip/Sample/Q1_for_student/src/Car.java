

class Car
 {String owner;
  int color;
  int size;
  Car(String xOwner, int xColor, int xsize)
   {owner=xOwner; color=xColor;size=xsize;
   }
  public String toString()
   {return("(" +owner+","+ color + ","+size+ ")");
   }
 }
